# FINHYPE

> **Zeckathon 2026 – Problem Statement 3**

## Objective

Forecast monthly net flows for Indian **liquid** and **overnight** mutual funds for the next three months, analyse the factors that drive those flows, compare forecasting models, and recommend an appropriate cash buffer for fund managers.

## Project Status

- **Phase 0 – Project Setup**: Complete.
- **Phase 1 – Historical Data Ingestion**: Complete. (90 months of AMFI data from April 2019 to September 2026).
- **Phase 2 – SQLite Database & Storage**: Complete. (Local SQLite DB at `data/finhype.db` with duplicate prevention and safe retrieval).
- **Phase 3 – EDA, Feature Engineering & External Factors**: Complete *(current)*.
- **Phase 4 – Model Development & Rolling-Origin Backtesting**: Pending user approval.
- **Phase 5 – Cash Buffer Engine & Streamlit Dashboard**: Pending.

## Repository Structure

```
FINHYPE/
├── app/
│   ├── __init__.py
│   ├── dashboard.py          # Streamlit front-end
│   ├── db.py                 # SQLite database access and query layer
│   ├── data/                 # Ingestion, scrapers, validators, external factors
│   │   ├── amfi_downloader.py
│   │   ├── amfi_parser.py
│   │   ├── amfi_scraper.py
│   │   ├── amfi_validator.py
│   │   ├── db.py
│   │   └── external_factors.py
│   ├── forecasting/          # EDA and Feature Engineering pipelines
│   │   ├── eda.py
│   │   └── feature_engineering.py
│   └── services/             # Business-logic services (planned)
├── data/
│   ├── finhype.db            # Local SQLite database
│   ├── raw/
│   │   ├── amfi/             # Raw AMFI monthly Excel workbooks
│   │   └── external/         # External macro factors & metadata JSON
│   └── processed/
│       ├── fund_flows_monthly.csv
│       ├── external_factors_monthly.csv
│       └── featured_fund_flows.csv
├── reports/
│   ├── eda_findings.md       # Comprehensive analytical findings report
│   └── figures/              # Interactive Plotly visual artifacts (HTML)
├── scripts/
│   ├── collect_data.py       # Phase 1 data collection runner
│   ├── init_db.py            # Phase 2 database initializer and CSV importer
│   ├── run_eda.py            # Phase 3 EDA computation & visual generator
│   ├── fetch_external_factors.py # Phase 3 external factor builder
│   └── build_features.py     # Phase 3 feature engineering pipeline runner
├── tests/                    # 93 automated unit and integration tests
├── .gitignore
├── requirements.txt
└── README.md
```

## Quick Start

### 1. Create and activate a virtual environment

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run Exploratory Data Analysis (EDA)

```bash
python scripts/run_eda.py
```
This generates the interactive Plotly figures in `reports/figures/` and updates the markdown findings in `reports/eda_findings.md`.

### 4. Build Feature Pipeline

```bash
python scripts/build_features.py
```
This generates `data/processed/featured_fund_flows.csv` with 53 engineered features (calendar, lags, rolling stats, churn, AUM growth, peer dynamics, and external macro factors).

### 5. Run All Tests

```bash
pytest
```
93 automated unit tests cover scrapers, parsers, database operations, external factor ingestion, EDA metrics, and leakage-prevention in feature engineering.

## Problem Statement Summary

Indian liquid and overnight mutual funds experience significant flow volatility driven by factors such as RBI policy rates, call-money rates, GST and advance-tax outflow cycles, corporate treasury behaviour, and broader equity-market sentiment. Accurate short-term (3-month) flow forecasting enables fund managers to pre-position liquidity and reduce transaction costs.

## Licence

MIT


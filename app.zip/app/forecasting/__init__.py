"""forecasting sub-package for FINHYPE."""

from app.forecasting.eda import (
    compute_category_summary_stats,
    compute_monthly_seasonality,
    compute_quarter_end_comparison,
    detect_outliers,
    plot_category_cross_correlation,
    plot_gross_flows_comparison,
    plot_net_flows_time_series,
    plot_outlier_analysis,
    plot_quarter_end_effect,
    plot_seasonality_calendar_month,
)
from app.forecasting.feature_engineering import (
    add_autoregressive_lags,
    add_calendar_features,
    add_cross_category_features,
    add_external_macro_features,
    add_gross_flow_and_aum_features,
    add_rolling_features,
    build_feature_pipeline,
    get_feature_manifest,
    get_model_ready_data,
)

__all__ = [
    "compute_category_summary_stats",
    "compute_quarter_end_comparison",
    "compute_monthly_seasonality",
    "detect_outliers",
    "plot_net_flows_time_series",
    "plot_gross_flows_comparison",
    "plot_seasonality_calendar_month",
    "plot_quarter_end_effect",
    "plot_outlier_analysis",
    "plot_category_cross_correlation",
    "add_calendar_features",
    "add_autoregressive_lags",
    "add_rolling_features",
    "add_gross_flow_and_aum_features",
    "add_cross_category_features",
    "add_external_macro_features",
    "build_feature_pipeline",
    "get_model_ready_data",
    "get_feature_manifest",
]


"""
FINHYPE – Streamlit Dashboard
Phase 0: Project Setup

Forecasting functionality is not yet implemented.
"""

import streamlit as st

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="FINHYPE",
    page_icon="📈",
    layout="wide",
)

# ── Header ───────────────────────────────────────────────────────────────────
st.title("📈 FINHYPE")
st.subheader("Mutual Fund Flow Forecasting and Liquidity Management")

st.divider()

# ── Status banner ─────────────────────────────────────────────────────────────
st.info(
    "**Status:** Initial setup complete — forecasting functionality is not yet implemented.",
    icon="🚧",
)

# ── Project overview ──────────────────────────────────────────────────────────
st.markdown(
    """
    ## Project Overview

    **FINHYPE** is being developed for **Zeckathon 2026 – Problem Statement 3**.

    | Field | Detail |
    |---|---|
    | **Objective** | Forecast monthly net flows for Indian liquid and overnight mutual funds for the next three months |
    | **Scope** | Factor analysis, multi-model comparison, and cash-buffer recommendation |
    | **Phase** | 0 – Project Setup |
    | **Next Phase** | Data ingestion and exploratory data analysis |
    """
)

st.divider()
st.caption("FINHYPE · Zeckathon 2026 · Phase 0")

